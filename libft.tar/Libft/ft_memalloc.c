/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   ft_memalloc.c                                    .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: manquez <marvin@le-101.fr>                 +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/10/14 09:31:34 by manquez      #+#   ##    ##    #+#       */
/*   Updated: 2018/10/14 09:41:28 by manquez     ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memalloc(size_t size)
{
	void *t;

	if (!(t = (void*)malloc(sizeof(*t) * size)))
		return (NULL);
	ft_memset(t, 0, size);
	return (t);
}
