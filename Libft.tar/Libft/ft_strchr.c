/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   ft_strchr.c                                      .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: manquez <marvin@le-101.fr>                 +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/10/10 11:32:38 by manquez      #+#   ##    ##    #+#       */
/*   Updated: 2018/10/10 12:36:00 by manquez     ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strchr(const char *s, int c)
{
	int		i;
	char	*tab;
	int		t;

	i = 0;
	tab = (char *)s;
	t = (char)c;
	while (tab[i] <= '\0')
	{
		if (tab[i] == t)
			return (tab + i);
		i++;
	}
	return (NULL);
}
