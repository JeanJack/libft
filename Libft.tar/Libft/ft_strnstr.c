/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   ft_strnstr.c                                     .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: manquez <marvin@le-101.fr>                 +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/10/13 13:50:52 by manquez      #+#   ##    ##    #+#       */
/*   Updated: 2018/10/13 14:45:25 by manquez     ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *haystack, const char *needle, size_t len)
{
	size_t i;
	size_t a;

	i = 0;
	if (len == 0)
		return (NULL);
	if (*needle == '\0')
		return ((char *)haystack);
	while (haystack[i])
	{
		a = 0;
		while (needle[a] == haystack[i + a])
		{
			if (a == len - 1)
				return ((char *)haystack + i);
			if (needle[a + 1] == '\0')
				return ((char *)haystack + i);
			a++;
		}
		i++;
	}
	return (0);
}
