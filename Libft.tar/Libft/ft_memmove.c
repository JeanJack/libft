/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   ft_memmove.c                                     .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: manquez <marvin@le-101.fr>                 +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/10/10 11:08:08 by manquez      #+#   ##    ##    #+#       */
/*   Updated: 2018/10/10 11:13:25 by manquez     ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memmove(void *dst, const void *src, size_t len)
{
	char	*alad1;
	char	*alad2;
	size_t	ala3;

	ala3 = 0;
	alad1 = (char *)dst;
	alad2 = (char *)src;
	if (alad2 < alad1)
	{
		while ((int)(--len) >= 0)
			*(alad1 + len) = *(alad2 + len);
	}
	else
		while (ala3 < len)
		{
			*(alad1 + ala3) = *(alad2 + ala3);
			ala3++;
		}
	return (dst);
}
