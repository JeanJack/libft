/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   ft_strcat.c                                      .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: manquez <marvin@le-101.fr>                 +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/10/15 13:35:40 by manquez      #+#   ##    ##    #+#       */
/*   Updated: 2018/10/16 10:32:55 by manquez     ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strcat(char *restrict s1, const char *restrict s2)
{
	size_t i;
	size_t n;

	i = 0;
	n = 0;
	while (s1[i])
		i++;
	while (s2[n])
		n++;
	if (!(s1 = (char*)malloc(sizeof(*s1) * (i + n + 1))))
		return (NULL);
	n = 0;
	while (s2[n])
	{
		s1[i] = s2[n];
		i++;
		n++;
	}
	s1[i] = '\0';
	return (s1);
}
