/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   ft_strstr.c                                      .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: manquez <marvin@le-101.fr>                 +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/10/10 14:03:14 by manquez      #+#   ##    ##    #+#       */
/*   Updated: 2018/10/10 15:06:17 by manquez     ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strstr(const char *haystack, const char *needle)
{
	int i;
	int a;

	i = 0;
	a = 0;
	if (*needle == '\0')
		return (haystack)
	while (haystack[i])
	{
		if (haystack[i] == needle[a])
		{
			while (haystack[i] == needle[a])
			{
				if (needle[a] == '\0')
					return (haystack)
				i++;
				a++;
			}
		}

	}
}
