#include "libft.h"

char	*ft_strstr(const char *haystack, const char *needle)
{
	int i;
	int a;

	i = 0;
	while (haystack[i])
	{
		a = 0;
		while (needle[a] == haystack[i + a])
		{
			if (needle[a + 1] == '\0')
				return (haystack + i);
			a++;
		}
		i++;
	}
	return (0);
}
