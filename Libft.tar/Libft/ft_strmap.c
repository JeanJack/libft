/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   ft_strmap.c                                      .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: manquez <marvin@le-101.fr>                 +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/10/12 10:10:25 by manquez      #+#   ##    ##    #+#       */
/*   Updated: 2018/10/12 11:10:55 by manquez     ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strmap(char const *s, char (*f) (char))
{
	size_t	i;
	size_t	a;
	char	*tab;

	i = 0;
	a = 0;
	while (s[a])
		a++;
	tab = (char*)malloc(sizeof(*tab) * (a + 1));
	while (s[i])
	{
		tab[i] = f(s[i]);
		i++;
	}
	return (tab);
}
