#include <strings.h>
#include <stdio.h>
#include <stdlib.h>

int		main(int ac, char **av)
{
	if (ac == 1)
		return (0);
	bzero(av[1], atoi(av[2]));
	printf("%s", av[1]);
	return (0);
}
