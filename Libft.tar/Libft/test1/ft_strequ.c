/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   ft_strequ.c                                      .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: manquez <marvin@le-101.fr>                 +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/10/12 12:27:12 by manquez      #+#   ##    ##    #+#       */
/*   Updated: 2018/10/12 13:28:31 by manquez     ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

int		ft_strequ(char const *s1, char const *s2)
{
	size_t i;

	i = 0;
	while (s1[i] && s2[i])
	{
		if (s2[i] != s1[i])
			return (0);
		i++;
	}
	if (s1[i] != s2[i])
		return (0);
	return (1);
}

int		main(int ac, char **av)
{
	if (ac == 1)
		return (0);
	printf("%d", ft_strequ(av[1], av[2]));
	return (0);
}
