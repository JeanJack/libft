/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   ft_strnstr.c                                     .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: manquez <marvin@le-101.fr>                 +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/10/13 13:50:52 by manquez      #+#   ##    ##    #+#       */
/*   Updated: 2018/10/16 13:16:12 by manquez     ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

char	*ft_strnstr(const char *haystack, const char *needle, size_t len)
{
	size_t i;
	size_t a;

	i = 0;
	if (len == 0)
		return (NULL);
	if (*needle == '\0')
		return ((char *)haystack);
	while (haystack[i])
	{
		a = 0;
		while (needle[a] == haystack[i + a])
		{
			if (a == len - 1)
				return ((char *)haystack + i);
			if (needle[a + 1] == '\0')
				return ((char *)haystack + i);
			a++;
		}
		i++;
	}
	return (0);
}

int		main(int ac , char **av)
{
	if (ac == 1)
		return (0);
	printf("%s", ft_strnstr(av[1], av[2], atoi(av[3])));
	return (0);
}
