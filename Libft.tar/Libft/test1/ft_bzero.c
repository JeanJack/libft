#include <stdio.h>
#include <stdlib.h>

void	ft_bzero(void *s, size_t n)
{
	size_t			i;
	unsigned char	*tab;

	tab = (unsigned char *)s;
	i = 0;
	while (i < n)
	{
		tab[i] = '\0';
		i++;
	}
}

int		main(int ac, char **av)
{
	if (ac == 1)
		return (0);
	ft_bzero(av[1], atoi(av[2]));
	printf("%s", av[1]);
	return (0);
}
