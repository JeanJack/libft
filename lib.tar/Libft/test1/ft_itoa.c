#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int		ft_intlen(int nb)
{
	int i;

	i = 0;
	if (nb < 0)
	{
		nb = nb * -1;
		i++;
	}
	while (nb > 0)
	{
		nb = nb / 10;
		i++;
	}
	return (i);
}

char	*ft_itoa(int nb)
{
	char	*s;
	int		i;

	if (nb == -2147483648)
		return (strdup("-2147483648"));
	i = ft_intlen(nb);
	if (!(s = (char*)malloc(sizeof(*s) * (i + 1))))
		return (NULL);
	s[i--] = '\0';
	if (nb == 0)
	{
		s[0] = 48;
		return (s);
	}
	if (nb < 0)
	{
		s[0] = '-';
		nb = nb * -1;
	}
	while (nb > 0)
	{
		s[i] = 48 + (nb % 10);
		nb = nb / 10;
		i--;
	}
	return (s);
}

int		main(int ac, char **av)
{
	if (ac == 1)
		return (0);
	printf("%s", ft_itoa(atoi(av[1])));
	return (0);
}
